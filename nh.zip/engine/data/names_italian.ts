export const ITALIAN_NAMES = [
  {
    "given_name": "Abundius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Abel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Abraham",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Achilles",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alberto",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Adam",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Adalhard",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Adhelm",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ealdhelm",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Otmar",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Adolf",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Adonis",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Adrian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Agathinus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alban",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alberich",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alberto",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Albert",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Albinus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alcides",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aleksanteri",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aleksi",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alessandro",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alejandro",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alejandra",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alexander",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alexius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alphaeus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alphius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alfred",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aloysius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Louis",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Amadeus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Amatus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Amator",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ambrogio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ambrose",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Amadeus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Emmerich",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hamilcar",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hamlet",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Amor",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anacletus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anastasius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Andrew",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Angelo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Angel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Angelo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anicetus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hannibal",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Annunziata",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Oswald",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anselm",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anthelm",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Antiochus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Antonio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Antoninus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anthony",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Antonio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Pio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hartwin",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aristides",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Herman",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Arnold",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Arnaldo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Arnulf",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Harold",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aaron",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Henry",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Arsenios",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Artemios",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Arthur",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ascanius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Athanasius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Augustus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aurelianus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aurelius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Balbinus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Balthazar",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Baldwin",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Theobald",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Baldassare",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Baldwin",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Barnabas",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Bartholomew",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Bartholomew",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Baptiste",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Benedict",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Benjamin",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Patrick",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Benedicto",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giuseppe",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Berard",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Bernardo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Bernard",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Roberto",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alberto",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Berthold",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Bertrand",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Benedetto",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Biagio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Biagio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Blaise",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Boniface",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Bosco",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Bruno",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gaius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Callistus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Camillus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Candidus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Charles",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Carmel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Carmen",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Casimir",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cassius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Othello",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Catellus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Caecilius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Caelestis",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Caelestinus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Caelinus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Marcelino",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Caelius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Celsus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Caesar",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cesare",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cyprian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cyriacus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cyril",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ciro",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cyrus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Claudius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Clement",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anacleto",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Columbanus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Columba",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Concetta",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gonzalo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cornelius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Corrado",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Conrad",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cosmas",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cosmas",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Cosimo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Constantine",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Constans",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Crescentius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Christian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Christopher",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Damian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Daniel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Daniel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Durante",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Darius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "David",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Demetrius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Desiderius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Santiago",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Deodatus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Dionisio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Dionysius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Dominic",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Donato",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Dorian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Edgar",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Edmund",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Edward",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giles",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Eleutherius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Elijah",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Eligius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aelius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Helios",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Heliodoro",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Elisha",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Guglielmo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anselmo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Erasmus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Elpidius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Helvius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Emmanuel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Emil",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Emil",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Emanuele",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aeneas",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Henry",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Heinz",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Anzo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Vincenzo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Lorenzo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jesus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aroldo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Erasmus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hercules",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hermagoras",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Herman",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hermenegildo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hermes",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hermes",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Herminius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ernest",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hector",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Eugene",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Eusebius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Eustace",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Euthymius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Matthew",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Mark",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Luke",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "John",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Evaristus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Aetius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Fabian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Fabius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Fabrice",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Faustus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Faustus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Fidel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Frederick",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Frederick",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Felix",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Felix",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ferdinand",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Philadelphos",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Filibert",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Philip",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Flora",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Florus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Florence",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Florinus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Flaminius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Flavian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Flavius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Florian",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Florus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Francis",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Francesco",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Pio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Frank",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Francesco",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Federico",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Alfredo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Goffredo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Fulgencio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gabriel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Galahad",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jesus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gallus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jasper",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jasper",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gaston",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Generosus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Genesius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gennaro",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Januarius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gerard",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jeremiah",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Germanus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jerome",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gervasius",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gerardo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Hyacinthus",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jacob",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "James",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Battista",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Paolo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Piero",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giovanni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Carlo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Franco",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Luigi",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Marco",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Maria",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giovanni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giovanni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Paolo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gianni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Piero",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Luigi",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gilbert",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gilda",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giovanni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Joachim",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Joachim",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Joel",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jonah",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jonathan",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Jordan",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giorgio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "George",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Joshua",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Ambrogio",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Angiolo",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Giovanni",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Battista",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "John",
    "culture": "italian",
    "gender": "male"
  },
  {
    "given_name": "Gerald",
    "culture": "italian",
    "gender": "male"
  }
];
