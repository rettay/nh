export const CHINESE_NAMES  = [
  {
    "given_name": "Wei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Qiang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Lei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ming",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Dong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jie",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Wen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hui",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kai",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Peng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xin",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Bo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Chao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Gang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Rui",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiqiang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yulong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jiahao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zihao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Haoran",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Siyuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhihui",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hongyi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Junjie",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yifeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiwei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jianguo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xinyi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Fang",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Na",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Min",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jing",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiuying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Li",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Juan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xia",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ping",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ling",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ting",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xue",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Lin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaoyan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaoyu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yating",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuting",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Siyi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Qian",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Tong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yao",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yifei",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jingyi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jiajia",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Mingyu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaohong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zhenzhen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuanyuan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zhen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Aixia",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Chunhua",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Aiguo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Junsheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Maimaiti",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yexi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhaxidunzhu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Abudureyimu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Adil",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Nurgul",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Temur",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Bateer",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Siqin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Wulantuya",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jiaming",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yijun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Peizhi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Huiling",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yawen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jinghui",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Weiming",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhihao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jingxuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xueying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Huiying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Chenghao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Lifen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Meifeng",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Liang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "An",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Long",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Shan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Feng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yun",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Guang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Mei",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Tao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hui",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Cheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hua",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Wei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ming",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jie",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Gang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Lei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Bo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Peng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hui",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Chao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Feng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Tao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Qiang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xin",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Dong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kai",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Wen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Bin",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Fei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Guang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Rui",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Long",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Cheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Sheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Da",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Nan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Shan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Guo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jin",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "An",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhuo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Liang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhihao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiqiang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Haoran",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Junjie",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jiahao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zihao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yuchen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Haoyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xinran",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yicheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Siyuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhenyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ruiyang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Tianyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ziyang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yifeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hongyi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yulong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiwei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yuxuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zixuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Minghao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Junyi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xinyi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Renjun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Qingfeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Mingyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jiayi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ruihan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhehan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kaiyuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yunxi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jingyi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Haoxuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yingjie",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ziwen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yizhe",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Chenxi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yankai",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Bowen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jincheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yiyang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jianguo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Wenxue",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Guoqiang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Aiguo",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Dejun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Weidong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hongqi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Desheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Min",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Juan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ling",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ting",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Qian",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Hui",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xia",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xue",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Lin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ping",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yao",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Qing",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Hua",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Mei",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Tong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Hong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Lan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zhen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jie",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Fen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Rong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zhi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Dan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Shu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xuan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yun",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaoyan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaohong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiuying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiulan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zhenzhen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yating",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yifei",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuting",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Siyi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xuanyi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jingyi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Qiuyue",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zixuan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuxin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuxi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xinyi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Mengyu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Chunhua",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jiajia",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Mingyu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuanyuan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuetong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jingjing",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaojie",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ziyue",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yijun",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Mengyao",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaowei",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ruoxi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xinran",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yilin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Qianwen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuyan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Tianhui",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jiaqi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiwen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Rouxi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Bingxin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Qiaoyi",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jingxuan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xinwen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuxuan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Ningxin",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Guiying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Guilan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zhenzhu",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yuhua",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Guirong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Xiuzhen",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Weihong",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Fengying",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jing",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Ping",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Xin",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Qi",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Kai",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Ya",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Yi",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Le",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Chen",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Zhong",
    "gender": "unisex",
    "culture": "chinese"
  },
  {
    "given_name": "Li",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Na",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Yan",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Jing",
    "gender": "female",
    "culture": "chinese"
  },
  {
    "given_name": "Zijian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zijing",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zilong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ziqi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zirui",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zitao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zitong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ziwen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ziyan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ziyue",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaowei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Pingfan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xingbao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Bao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Chang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Chun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Da",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "De",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "En",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Fu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Gong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Guang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Han",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "He",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hua",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ji",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jie",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jin",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Liang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Meng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ning",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ping",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Qi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Quan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ren",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Sheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Song",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Tang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Tian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ye",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ying",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yue",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhuang",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Anwei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Bojun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Chenxi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Dawei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Deming",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Enlai",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Fenghua",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Guanyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Haowen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Hongzhi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jiaheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jianfeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jiawei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Jinhai",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kangming",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Kunpeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Liangyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Lingfeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Longwei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Minghao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ningfeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Penghao",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Qiangwei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Qianfeng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ruohan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Shaohua",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Shengli",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Tairan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Weibin",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Weichen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Wenjun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Wenxuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiangyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaolong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xiaoming",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Xinghan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yangkai",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yiheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yingqi",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yitian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Youwei",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yuande",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yuanjun",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yucheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Yunshen",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zeyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhihan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhijian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiping",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhirong",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhisheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiyan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhiyu",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zhongping",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Ziheng",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zihuan",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zijian",
    "gender": "male",
    "culture": "chinese"
  },
  {
    "given_name": "Zijun",
    "gender": "male",
    "culture": "chinese"
  }
];
